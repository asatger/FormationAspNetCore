﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NetFlox.DAL
{
    public class Role
    {
        public int Id { get; set; }
        public string Libelle { get; set; }
    }
}
